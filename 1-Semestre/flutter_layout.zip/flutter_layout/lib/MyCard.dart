import 'package:flutter/material.dart';

class MyCard extends StatelessWidget{
  final IconData icon;
  final String contato;

  MyCard(this.icon, this.contato){}

  @override
  Widget build(BuildContext context) {
    return Card(
            margin: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Padding(
              padding: const EdgeInsets.all(15),
              child: Row(
                children: [
                  Icon(icon, color: Colors.blue),
                  SizedBox(
                    width: 30,
                  ),
                  Text(contato)
                ],
              ),
            ),
          );
  }

}