import 'dart:html';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_layout/MyCard.dart';

void main() {
  runApp(MaterialApp(
    home: MyApp(),
  ));
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue,
      body: SafeArea(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          CircleAvatar(
            backgroundImage: AssetImage('images/avatar.jpg'),
            radius: 60,
          ),
          Text(
            'Manuel Gomes',
            style: TextStyle(
              fontFamily: 'Pacifico',
              color: Colors.white,
              fontSize: 40,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            'FLUTTER DEVELOPER',
            style: TextStyle(
              fontFamily: 'Pacifico',
              color: Colors.white,
              fontSize: 15,
              fontWeight: FontWeight.normal,
            ),
          ),
          MyCard(Icons.phone, '+55 (11) 25478-6521'),
          MyCard(Icons.email, 'manuel.gomes@gmail.com'),
        ]),
      ),
    );
  }
}
