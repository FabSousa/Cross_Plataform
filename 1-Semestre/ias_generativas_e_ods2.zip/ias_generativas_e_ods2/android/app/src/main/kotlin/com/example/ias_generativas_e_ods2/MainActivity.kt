package com.example.ias_generativas_e_ods2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
