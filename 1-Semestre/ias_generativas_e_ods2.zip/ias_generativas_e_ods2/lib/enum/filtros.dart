enum Filtros {
  cultura,
  agua,
  nutrientes,
  pragas,
}
