enum Nutrientes {
  nitrogenio,
  potassio,
  fosforo,
  calcio,
  magnesio,
  enxofre,
}
