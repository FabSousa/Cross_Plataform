enum Culturas {
  soja,
  milho,
  trigo,
  cafe,
}
