enum NivelDeAgua {
  excessivo,
  alto,
  medio,
  baixo,
  critico,
}