enum PragasDoencas {
  lagartas,
  fungos,
  bacterias,
  virus,
}
