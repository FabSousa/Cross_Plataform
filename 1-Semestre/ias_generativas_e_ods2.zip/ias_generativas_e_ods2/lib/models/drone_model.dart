class DroneModel {
  int id;
  int battery;
  String status;
  String coordinates;

  DroneModel({
    required this.id,
    required this.battery,
    required this.status,
    required this.coordinates,
  });
}
