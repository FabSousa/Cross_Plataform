import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      home: Scaffold(
        drawer: Drawer(
          backgroundColor: Colors.white,
          child: Column(
            children: [
              UserAccountsDrawerHeader(
                currentAccountPicture:
                    CircleAvatar(backgroundImage: AssetImage("../images/pfp.jpg"),),
                accountName: Text("Manuel Gomes"),
                accountEmail: Text("manuel.gomes@gmail.com"),
              ),
              ListTile(
                title: Text("Primary"),
                leading: Icon(Icons.inbox),
              ),
              ListTile(
                title: Text("Social"),
                leading: Icon(Icons.people),
              ),
              ListTile(
                title: Text("Promotions"),
                leading: Icon(Icons.tag),
              ),
            ],
          ),
        ),
        appBar: AppBar(
          backgroundColor: Colors.blue,
          title: Text("Checkpoint 1"),
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Fabio",
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.facebook,
                  color: Colors.blue,
                ),
                Icon(
                  Icons.phone,
                  color: Colors.green,
                ),
                Icon(
                  Icons.mail,
                  color: Colors.red,
                )
              ],
            )
          ],
        ),
        floatingActionButton: FloatingActionButton(
          child: Icon(Icons.whatsapp),
          backgroundColor: Colors.green,
          onPressed: null,
        ),
      ),
    ),
  );
}
